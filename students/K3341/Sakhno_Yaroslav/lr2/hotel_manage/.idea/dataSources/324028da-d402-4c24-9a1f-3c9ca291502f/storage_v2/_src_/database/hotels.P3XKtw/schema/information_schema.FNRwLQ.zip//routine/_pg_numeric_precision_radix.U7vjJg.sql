CREATE FUNCTION _pg_numeric_precision_radix(typid oid, typmod integer) RETURNS integer
    IMMUTABLE STRICT PARALLEL SAFE
    LANGUAGE sql AS
$$SELECT
  CASE WHEN $1 IN (21, 23, 20, 700, 701) THEN 2
       WHEN $1 IN (1700) THEN 10
       ELSE null
  END$$;

ALTER FUNCTION _pg_numeric_precision_radix(OID, INTEGER) OWNER TO postgres;

