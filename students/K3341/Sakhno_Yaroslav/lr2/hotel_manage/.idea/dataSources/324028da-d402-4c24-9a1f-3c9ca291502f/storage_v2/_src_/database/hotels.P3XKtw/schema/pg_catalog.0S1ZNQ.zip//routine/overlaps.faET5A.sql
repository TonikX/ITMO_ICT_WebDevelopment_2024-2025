CREATE FUNCTION "overlaps"(timestamp with time zone, interval, timestamp with time zone, timestamp with time zone) RETURNS boolean
    STABLE PARALLEL SAFE COST 1
    LANGUAGE sql AS
$$select ($1, ($1 + $2)) overlaps ($3, $4)$$;

COMMENT ON FUNCTION "overlaps"(TIMESTAMP WITH TIME ZONE, INTERVAL, TIMESTAMP WITH TIME ZONE, TIMESTAMP WITH TIME ZONE) IS 'intervals overlap?';

ALTER FUNCTION "overlaps"(TIMESTAMP WITH TIME ZONE, INTERVAL, TIMESTAMP WITH TIME ZONE, TIMESTAMP WITH TIME ZONE) OWNER TO postgres;

