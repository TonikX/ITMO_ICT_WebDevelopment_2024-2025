CREATE FUNCTION xpath_exists(text, xml) RETURNS boolean
    IMMUTABLE STRICT PARALLEL SAFE COST 1
    LANGUAGE sql AS
$$select pg_catalog.xpath_exists($1, $2, '{}'::pg_catalog.text[])$$;

COMMENT ON FUNCTION xpath_exists(TEXT, XML) IS 'test XML value against XPath expression';

ALTER FUNCTION xpath_exists(TEXT, XML) OWNER TO postgres;

