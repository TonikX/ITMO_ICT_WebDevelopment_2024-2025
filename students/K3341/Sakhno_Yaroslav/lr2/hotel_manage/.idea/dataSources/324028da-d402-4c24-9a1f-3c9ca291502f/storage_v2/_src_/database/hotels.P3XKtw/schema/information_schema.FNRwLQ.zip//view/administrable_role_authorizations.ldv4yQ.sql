CREATE VIEW administrable_role_authorizations(grantee, role_name, is_grantable) AS
SELECT applicable_roles.grantee, applicable_roles.role_name, applicable_roles.is_grantable
FROM information_schema.applicable_roles
WHERE applicable_roles.is_grantable::TEXT = 'YES'::TEXT;

ALTER TABLE administrable_role_authorizations
OWNER TO postgres;

GRANT SELECT ON administrable_role_authorizations TO PUBLIC;

