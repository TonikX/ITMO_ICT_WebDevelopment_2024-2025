CREATE VIEW foreign_server_options (foreign_server_catalog, foreign_server_name, option_name, option_value) AS
SELECT s.foreign_server_catalog, s.foreign_server_name,
    (pg_options_to_table(s.srvoptions)).option_name::information_schema.SQL_IDENTIFIER AS option_name,
    (pg_options_to_table(s.srvoptions)).option_value::information_schema.CHARACTER_DATA AS option_value
FROM information_schema._pg_foreign_servers s;

ALTER TABLE foreign_server_options
OWNER TO postgres;

GRANT SELECT ON foreign_server_options TO PUBLIC;

