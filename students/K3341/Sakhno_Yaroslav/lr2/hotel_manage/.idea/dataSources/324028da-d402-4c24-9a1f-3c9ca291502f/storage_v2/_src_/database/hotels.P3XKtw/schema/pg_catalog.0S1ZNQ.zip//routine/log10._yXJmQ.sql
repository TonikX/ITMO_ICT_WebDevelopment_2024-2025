CREATE FUNCTION log10(numeric) RETURNS numeric
    IMMUTABLE STRICT PARALLEL SAFE COST 1
    LANGUAGE sql AS
$$select pg_catalog.log(10, $1)$$;

COMMENT ON FUNCTION log10(NUMERIC) IS 'base 10 logarithm';

ALTER FUNCTION log10(NUMERIC) OWNER TO postgres;

