CREATE VIEW pg_timezone_abbrevs(abbrev, utc_offset, is_dst) AS
SELECT pg_timezone_abbrevs.abbrev, pg_timezone_abbrevs.utc_offset, pg_timezone_abbrevs.is_dst
FROM pg_timezone_abbrevs() pg_timezone_abbrevs(abbrev, utc_offset, is_dst);

ALTER TABLE pg_timezone_abbrevs
OWNER TO postgres;

GRANT SELECT ON pg_timezone_abbrevs TO PUBLIC;

