CREATE FUNCTION age(timestamp without time zone) RETURNS interval
    STABLE STRICT PARALLEL SAFE COST 1
    LANGUAGE sql AS
$$select pg_catalog.age(cast(current_date as timestamp without time zone), $1)$$;

COMMENT ON FUNCTION age(TIMESTAMP) IS 'date difference from today preserving months and years';

ALTER FUNCTION age(TIMESTAMP) OWNER TO postgres;

