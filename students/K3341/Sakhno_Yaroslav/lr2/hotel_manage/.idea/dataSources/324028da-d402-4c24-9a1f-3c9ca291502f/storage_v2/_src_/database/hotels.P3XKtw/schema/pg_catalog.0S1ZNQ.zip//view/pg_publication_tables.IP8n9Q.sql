CREATE VIEW pg_publication_tables(pubname, schemaname, tablename) AS
SELECT p.pubname, n.nspname AS schemaname, c.relname AS tablename
FROM pg_publication p,
    LATERAL pg_get_publication_tables(p.pubname::TEXT) gpt(relid),
    pg_class c
        JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE c.oid = gpt.relid;

ALTER TABLE pg_publication_tables
OWNER TO postgres;

GRANT SELECT ON pg_publication_tables TO PUBLIC;

