CREATE VIEW pg_locks
            (locktype, database, relation, page, tuple, virtualxid, transactionid, classid, objid, objsubid,
             virtualtransaction, pid, mode, granted, fastpath)
AS
SELECT l.locktype, l.database, l.relation, l.page, l.tuple, l.virtualxid, l.transactionid, l.classid, l.objid,
    l.objsubid, l.virtualtransaction, l.pid, l.mode, l.granted, l.fastpath
FROM pg_lock_status() l(locktype, database, relation, page, tuple, virtualxid, transactionid, classid, objid, objsubid,
                        virtualtransaction, pid, mode, granted, fastpath);

ALTER TABLE pg_locks
OWNER TO postgres;

GRANT SELECT ON pg_locks TO PUBLIC;

