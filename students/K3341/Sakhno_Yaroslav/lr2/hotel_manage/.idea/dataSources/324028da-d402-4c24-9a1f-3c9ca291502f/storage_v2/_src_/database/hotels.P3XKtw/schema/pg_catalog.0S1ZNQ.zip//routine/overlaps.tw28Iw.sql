CREATE FUNCTION "overlaps"(time without time zone, interval, time without time zone, interval) RETURNS boolean
    IMMUTABLE PARALLEL SAFE COST 1
    LANGUAGE sql AS
$$select ($1, ($1 + $2)) overlaps ($3, ($3 + $4))$$;

COMMENT ON FUNCTION "overlaps"(TIME, INTERVAL, TIME, INTERVAL) IS 'intervals overlap?';

ALTER FUNCTION "overlaps"(TIME, INTERVAL, TIME, INTERVAL) OWNER TO postgres;

