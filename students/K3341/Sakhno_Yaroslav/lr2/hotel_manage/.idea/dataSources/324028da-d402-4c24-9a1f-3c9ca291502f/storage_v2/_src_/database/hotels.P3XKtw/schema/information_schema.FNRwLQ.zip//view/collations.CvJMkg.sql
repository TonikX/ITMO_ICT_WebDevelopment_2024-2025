CREATE VIEW collations(collation_catalog, collation_schema, collation_name, pad_attribute) AS
SELECT current_database()::information_schema.SQL_IDENTIFIER AS collation_catalog,
    nc.nspname::information_schema.SQL_IDENTIFIER AS collation_schema,
    c.collname::information_schema.SQL_IDENTIFIER AS collation_name,
    'NO PAD'::CHARACTER VARYING::information_schema.CHARACTER_DATA AS pad_attribute
FROM pg_collation c, pg_namespace nc
WHERE c.collnamespace = nc.oid AND
    (c.collencoding = ANY (ARRAY ['-1'::INTEGER, (SELECT pg_database.encoding
                                                  FROM pg_database
                                                  WHERE pg_database.datname = current_database())]));

ALTER TABLE collations
OWNER TO postgres;

GRANT SELECT ON collations TO PUBLIC;

