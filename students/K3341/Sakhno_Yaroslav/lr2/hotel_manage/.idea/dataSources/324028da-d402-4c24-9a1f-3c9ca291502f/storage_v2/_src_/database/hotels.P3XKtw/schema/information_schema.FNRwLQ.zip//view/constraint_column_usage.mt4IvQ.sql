CREATE VIEW constraint_column_usage
            (table_catalog, table_schema, table_name, column_name, constraint_catalog, constraint_schema,
             constraint_name) AS
SELECT current_database()::information_schema.SQL_IDENTIFIER AS table_catalog,
    x.tblschema::information_schema.SQL_IDENTIFIER AS table_schema,
    x.tblname::information_schema.SQL_IDENTIFIER AS table_name,
    x.colname::information_schema.SQL_IDENTIFIER AS column_name,
    current_database()::information_schema.SQL_IDENTIFIER AS constraint_catalog,
    x.cstrschema::information_schema.SQL_IDENTIFIER AS constraint_schema,
    x.cstrname::information_schema.SQL_IDENTIFIER AS constraint_name
FROM (SELECT DISTINCT nr.nspname, r.relname, r.relowner, a.attname, nc.nspname, c.conname
      FROM pg_namespace nr, pg_class r, pg_attribute a, pg_depend d, pg_namespace nc, pg_constraint c
      WHERE nr.oid = r.relnamespace AND r.oid = a.attrelid AND d.refclassid = 'pg_class'::REGCLASS::OID AND
          d.refobjid = r.oid AND d.refobjsubid = a.attnum AND d.classid = 'pg_constraint'::REGCLASS::OID AND
          d.objid = c.oid AND c.connamespace = nc.oid AND c.contype = 'c'::"char" AND
          (r.relkind = ANY (ARRAY ['r'::"char", 'p'::"char"])) AND NOT a.attisdropped
      UNION ALL
      SELECT nr.nspname, r.relname, r.relowner, a.attname, nc.nspname, c.conname
      FROM pg_namespace nr, pg_class r, pg_attribute a, pg_namespace nc, pg_constraint c
      WHERE nr.oid = r.relnamespace AND r.oid = a.attrelid AND nc.oid = c.connamespace AND
          r.oid = CASE c.contype WHEN 'f'::"char" THEN c.confrelid ELSE c.conrelid END AND
          (a.attnum = ANY (CASE c.contype WHEN 'f'::"char" THEN c.confkey ELSE c.conkey END)) AND NOT a.attisdropped AND
          (c.contype = ANY (ARRAY ['p'::"char", 'u'::"char", 'f'::"char"])) AND
          (r.relkind = ANY (ARRAY ['r'::"char", 'p'::"char"]))) x(tblschema, tblname, tblowner, colname, cstrschema, cstrname)
WHERE pg_has_role(x.tblowner, 'USAGE'::TEXT);

ALTER TABLE constraint_column_usage
OWNER TO postgres;

GRANT SELECT ON constraint_column_usage TO PUBLIC;

