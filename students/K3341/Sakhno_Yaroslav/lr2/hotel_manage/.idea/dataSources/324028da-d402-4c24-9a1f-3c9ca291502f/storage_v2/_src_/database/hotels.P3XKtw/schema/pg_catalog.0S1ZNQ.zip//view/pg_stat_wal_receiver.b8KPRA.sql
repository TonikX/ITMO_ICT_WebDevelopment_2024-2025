CREATE VIEW pg_stat_wal_receiver
            (pid, status, receive_start_lsn, receive_start_tli, received_lsn, received_tli, last_msg_send_time,
             last_msg_receipt_time, latest_end_lsn, latest_end_time, slot_name, sender_host, sender_port, conninfo)
AS
SELECT s.pid, s.status, s.receive_start_lsn, s.receive_start_tli, s.received_lsn, s.received_tli, s.last_msg_send_time,
    s.last_msg_receipt_time, s.latest_end_lsn, s.latest_end_time, s.slot_name, s.sender_host, s.sender_port, s.conninfo
FROM pg_stat_get_wal_receiver() s(pid, status, receive_start_lsn, receive_start_tli, received_lsn, received_tli,
                                  last_msg_send_time, last_msg_receipt_time, latest_end_lsn, latest_end_time, slot_name,
                                  sender_host, sender_port, conninfo)
WHERE s.pid IS NOT NULL;

ALTER TABLE pg_stat_wal_receiver
OWNER TO postgres;

GRANT SELECT ON pg_stat_wal_receiver TO PUBLIC;

