CREATE VIEW role_table_grants
            (grantor, grantee, table_catalog, table_schema, table_name, privilege_type, is_grantable, with_hierarchy) AS
SELECT table_privileges.grantor, table_privileges.grantee, table_privileges.table_catalog,
    table_privileges.table_schema, table_privileges.table_name, table_privileges.privilege_type,
    table_privileges.is_grantable, table_privileges.with_hierarchy
FROM information_schema.table_privileges
WHERE (table_privileges.grantor::NAME IN (SELECT enabled_roles.role_name FROM information_schema.enabled_roles)) OR
    (table_privileges.grantee::NAME IN (SELECT enabled_roles.role_name FROM information_schema.enabled_roles));

ALTER TABLE role_table_grants
OWNER TO postgres;

GRANT SELECT ON role_table_grants TO PUBLIC;

