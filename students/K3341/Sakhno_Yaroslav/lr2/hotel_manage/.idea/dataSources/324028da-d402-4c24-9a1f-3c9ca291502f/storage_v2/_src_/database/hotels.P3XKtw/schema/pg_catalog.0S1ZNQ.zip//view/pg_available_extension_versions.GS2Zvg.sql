CREATE VIEW pg_available_extension_versions
            (name, version, installed, superuser, relocatable, schema, requires, comment) AS
SELECT e.name, e.version, x.extname IS NOT NULL AS installed, e.superuser, e.relocatable, e.schema, e.requires,
    e.comment
FROM pg_available_extension_versions() e(name, version, superuser, relocatable, schema, requires, comment)
         LEFT JOIN pg_extension x ON e.name = x.extname AND e.version = x.extversion;

ALTER TABLE pg_available_extension_versions
OWNER TO postgres;

GRANT SELECT ON pg_available_extension_versions TO PUBLIC;

