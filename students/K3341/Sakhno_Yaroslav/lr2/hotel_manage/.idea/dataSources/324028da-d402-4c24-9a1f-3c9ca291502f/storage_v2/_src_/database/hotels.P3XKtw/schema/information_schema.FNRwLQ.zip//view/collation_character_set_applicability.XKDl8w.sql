CREATE VIEW collation_character_set_applicability
            (collation_catalog, collation_schema, collation_name, character_set_catalog, character_set_schema,
             character_set_name) AS
SELECT current_database()::information_schema.SQL_IDENTIFIER AS collation_catalog,
    nc.nspname::information_schema.SQL_IDENTIFIER AS collation_schema,
    c.collname::information_schema.SQL_IDENTIFIER AS collation_name,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS character_set_catalog,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS character_set_schema,
    getdatabaseencoding()::information_schema.SQL_IDENTIFIER AS character_set_name
FROM pg_collation c, pg_namespace nc
WHERE c.collnamespace = nc.oid AND
    (c.collencoding = ANY (ARRAY ['-1'::INTEGER, (SELECT pg_database.encoding
                                                  FROM pg_database
                                                  WHERE pg_database.datname = current_database())]));

ALTER TABLE collation_character_set_applicability
OWNER TO postgres;

GRANT SELECT ON collation_character_set_applicability TO PUBLIC;

