CREATE FUNCTION _pg_index_position(oid, smallint) RETURNS integer
    STABLE STRICT
    LANGUAGE sql AS
$$
SELECT (ss.a).n FROM
  (SELECT information_schema._pg_expandarray(indkey) AS a
   FROM pg_catalog.pg_index WHERE indexrelid = $1) ss
  WHERE (ss.a).x = $2;
$$;

ALTER FUNCTION _pg_index_position(OID, SMALLINT) OWNER TO postgres;

