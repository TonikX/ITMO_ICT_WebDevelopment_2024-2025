CREATE VIEW column_column_usage (table_catalog, table_schema, table_name, column_name, dependent_column) AS
SELECT current_database()::information_schema.SQL_IDENTIFIER AS table_catalog,
    n.nspname::information_schema.SQL_IDENTIFIER AS table_schema,
    c.relname::information_schema.SQL_IDENTIFIER AS table_name,
    ac.attname::information_schema.SQL_IDENTIFIER AS column_name,
    ad.attname::information_schema.SQL_IDENTIFIER AS dependent_column
FROM pg_namespace n, pg_class c, pg_depend d, pg_attribute ac, pg_attribute ad
WHERE n.oid = c.relnamespace AND c.oid = ac.attrelid AND c.oid = ad.attrelid AND
    d.classid = 'pg_class'::REGCLASS::OID AND d.refclassid = 'pg_class'::REGCLASS::OID AND d.objid = d.refobjid AND
    c.oid = d.objid AND d.objsubid = ad.attnum AND d.refobjsubid = ac.attnum AND ad.attgenerated <> ''::"char" AND
    pg_has_role(c.relowner, 'USAGE'::TEXT);

ALTER TABLE column_column_usage
OWNER TO postgres;

GRANT SELECT ON column_column_usage TO PUBLIC;

