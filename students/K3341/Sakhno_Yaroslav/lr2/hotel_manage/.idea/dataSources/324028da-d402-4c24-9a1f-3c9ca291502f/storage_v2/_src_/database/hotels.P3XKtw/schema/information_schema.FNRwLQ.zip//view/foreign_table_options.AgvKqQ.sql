CREATE VIEW foreign_table_options
            (foreign_table_catalog, foreign_table_schema, foreign_table_name, option_name, option_value) AS
SELECT t.foreign_table_catalog, t.foreign_table_schema, t.foreign_table_name,
    (pg_options_to_table(t.ftoptions)).option_name::information_schema.SQL_IDENTIFIER AS option_name,
    (pg_options_to_table(t.ftoptions)).option_value::information_schema.CHARACTER_DATA AS option_value
FROM information_schema._pg_foreign_tables t;

ALTER TABLE foreign_table_options
OWNER TO postgres;

GRANT SELECT ON foreign_table_options TO PUBLIC;

