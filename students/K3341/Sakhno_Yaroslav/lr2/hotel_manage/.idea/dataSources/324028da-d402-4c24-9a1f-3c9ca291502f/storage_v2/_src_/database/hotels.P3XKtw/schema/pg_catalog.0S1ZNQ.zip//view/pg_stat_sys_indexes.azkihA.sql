CREATE VIEW pg_stat_sys_indexes
            (relid, indexrelid, schemaname, relname, indexrelname, idx_scan, idx_tup_read, idx_tup_fetch) AS
SELECT pg_stat_all_indexes.relid, pg_stat_all_indexes.indexrelid, pg_stat_all_indexes.schemaname,
    pg_stat_all_indexes.relname, pg_stat_all_indexes.indexrelname, pg_stat_all_indexes.idx_scan,
    pg_stat_all_indexes.idx_tup_read, pg_stat_all_indexes.idx_tup_fetch
FROM pg_stat_all_indexes
WHERE (pg_stat_all_indexes.schemaname = ANY (ARRAY ['pg_catalog'::NAME, 'information_schema'::NAME])) OR
    pg_stat_all_indexes.schemaname ~ '^pg_toast'::TEXT;

ALTER TABLE pg_stat_sys_indexes
OWNER TO postgres;

GRANT SELECT ON pg_stat_sys_indexes TO PUBLIC;

