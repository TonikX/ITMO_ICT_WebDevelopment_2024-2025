CREATE FUNCTION substring(text, text, text) RETURNS text
    IMMUTABLE STRICT PARALLEL SAFE COST 1
    LANGUAGE sql AS
$$select pg_catalog.substring($1, pg_catalog.similar_escape($2, $3))$$;

COMMENT ON FUNCTION substring(TEXT, TEXT, TEXT) IS 'extract text matching SQL99 regular expression';

ALTER FUNCTION substring(TEXT, TEXT, TEXT) OWNER TO postgres;

