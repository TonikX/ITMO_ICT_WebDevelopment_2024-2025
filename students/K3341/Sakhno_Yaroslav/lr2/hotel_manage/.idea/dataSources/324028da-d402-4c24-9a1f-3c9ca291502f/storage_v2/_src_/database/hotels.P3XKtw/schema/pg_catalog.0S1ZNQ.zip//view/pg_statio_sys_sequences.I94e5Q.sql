CREATE VIEW pg_statio_sys_sequences(relid, schemaname, relname, blks_read, blks_hit) AS
SELECT pg_statio_all_sequences.relid, pg_statio_all_sequences.schemaname, pg_statio_all_sequences.relname,
    pg_statio_all_sequences.blks_read, pg_statio_all_sequences.blks_hit
FROM pg_statio_all_sequences
WHERE (pg_statio_all_sequences.schemaname = ANY (ARRAY ['pg_catalog'::NAME, 'information_schema'::NAME])) OR
    pg_statio_all_sequences.schemaname ~ '^pg_toast'::TEXT;

ALTER TABLE pg_statio_sys_sequences
OWNER TO postgres;

GRANT SELECT ON pg_statio_sys_sequences TO PUBLIC;

