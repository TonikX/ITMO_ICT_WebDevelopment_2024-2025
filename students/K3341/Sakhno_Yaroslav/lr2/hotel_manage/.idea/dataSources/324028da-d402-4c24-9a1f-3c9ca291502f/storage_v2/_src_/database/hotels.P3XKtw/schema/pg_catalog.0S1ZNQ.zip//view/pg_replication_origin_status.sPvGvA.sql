CREATE VIEW pg_replication_origin_status(local_id, external_id, remote_lsn, local_lsn) AS
SELECT pg_show_replication_origin_status.local_id, pg_show_replication_origin_status.external_id,
    pg_show_replication_origin_status.remote_lsn, pg_show_replication_origin_status.local_lsn
FROM pg_show_replication_origin_status() pg_show_replication_origin_status(local_id, external_id, remote_lsn, local_lsn);

ALTER TABLE pg_replication_origin_status
OWNER TO postgres;

