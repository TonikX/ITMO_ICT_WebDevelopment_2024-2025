CREATE VIEW domain_constraints
            (constraint_catalog, constraint_schema, constraint_name, domain_catalog, domain_schema, domain_name,
             is_deferrable, initially_deferred)
AS
SELECT current_database()::information_schema.SQL_IDENTIFIER AS constraint_catalog,
    rs.nspname::information_schema.SQL_IDENTIFIER AS constraint_schema,
    con.conname::information_schema.SQL_IDENTIFIER AS constraint_name,
    current_database()::information_schema.SQL_IDENTIFIER AS domain_catalog,
    n.nspname::information_schema.SQL_IDENTIFIER AS domain_schema,
    t.typname::information_schema.SQL_IDENTIFIER AS domain_name,
    CASE WHEN con.condeferrable THEN 'YES'::TEXT ELSE 'NO'::TEXT END::information_schema.YES_OR_NO AS is_deferrable,
    CASE WHEN con.condeferred THEN 'YES'::TEXT ELSE 'NO'::TEXT END::information_schema.YES_OR_NO AS initially_deferred
FROM pg_namespace rs, pg_namespace n, pg_constraint con, pg_type t
WHERE rs.oid = con.connamespace AND n.oid = t.typnamespace AND t.oid = con.contypid AND
    (pg_has_role(t.typowner, 'USAGE'::TEXT) OR has_type_privilege(t.oid, 'USAGE'::TEXT));

ALTER TABLE domain_constraints
OWNER TO postgres;

GRANT SELECT ON domain_constraints TO PUBLIC;

