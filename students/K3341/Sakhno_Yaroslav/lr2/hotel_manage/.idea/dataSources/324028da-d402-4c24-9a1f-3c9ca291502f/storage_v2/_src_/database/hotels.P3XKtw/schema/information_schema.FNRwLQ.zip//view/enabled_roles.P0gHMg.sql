CREATE VIEW enabled_roles(role_name) AS
SELECT a.rolname::information_schema.SQL_IDENTIFIER AS role_name
FROM pg_authid a
WHERE pg_has_role(a.oid, 'USAGE'::TEXT);

ALTER TABLE enabled_roles
OWNER TO postgres;

GRANT SELECT ON enabled_roles TO PUBLIC;

