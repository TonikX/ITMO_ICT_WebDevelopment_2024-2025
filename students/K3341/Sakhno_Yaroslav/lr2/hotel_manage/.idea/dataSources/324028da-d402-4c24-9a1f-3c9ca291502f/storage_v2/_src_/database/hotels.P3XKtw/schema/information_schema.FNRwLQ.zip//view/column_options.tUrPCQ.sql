CREATE VIEW column_options (table_catalog, table_schema, table_name, column_name, option_name, option_value) AS
SELECT current_database()::information_schema.SQL_IDENTIFIER AS table_catalog,
    c.nspname::information_schema.SQL_IDENTIFIER AS table_schema,
    c.relname::information_schema.SQL_IDENTIFIER AS table_name,
    c.attname::information_schema.SQL_IDENTIFIER AS column_name,
    (pg_options_to_table(c.attfdwoptions)).option_name::information_schema.SQL_IDENTIFIER AS option_name,
    (pg_options_to_table(c.attfdwoptions)).option_value::information_schema.CHARACTER_DATA AS option_value
FROM information_schema._pg_foreign_table_columns c;

ALTER TABLE column_options
OWNER TO postgres;

GRANT SELECT ON column_options TO PUBLIC;

