CREATE FUNCTION int8pl_inet(bigint, inet) RETURNS inet
    IMMUTABLE STRICT PARALLEL SAFE COST 1
    LANGUAGE sql AS
$$select $2 + $1$$;

COMMENT ON FUNCTION int8pl_inet(BIGINT, INET) IS 'implementation of + operator';

ALTER FUNCTION int8pl_inet(BIGINT, INET) OWNER TO postgres;

