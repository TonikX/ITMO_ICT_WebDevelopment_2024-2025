CREATE VIEW columns
            (table_catalog, table_schema, table_name, column_name, ordinal_position, column_default, is_nullable,
             data_type, character_maximum_length, character_octet_length, numeric_precision, numeric_precision_radix,
             numeric_scale, datetime_precision, interval_type, interval_precision, character_set_catalog,
             character_set_schema, character_set_name, collation_catalog, collation_schema, collation_name,
             domain_catalog, domain_schema, domain_name, udt_catalog, udt_schema, udt_name, scope_catalog, scope_schema,
             scope_name, maximum_cardinality, dtd_identifier, is_self_referencing, is_identity, identity_generation,
             identity_start, identity_increment, identity_maximum, identity_minimum, identity_cycle, is_generated,
             generation_expression, is_updatable)
AS
SELECT current_database()::information_schema.SQL_IDENTIFIER AS table_catalog,
    nc.nspname::information_schema.SQL_IDENTIFIER AS table_schema,
    c.relname::information_schema.SQL_IDENTIFIER AS table_name,
    a.attname::information_schema.SQL_IDENTIFIER AS column_name,
    a.attnum::information_schema.CARDINAL_NUMBER AS ordinal_position,
    CASE WHEN a.attgenerated = ''::"char"
             THEN pg_get_expr(ad.adbin, ad.adrelid)
         ELSE NULL::TEXT END::information_schema.CHARACTER_DATA AS column_default,
    CASE WHEN a.attnotnull OR t.typtype = 'd'::"char" AND t.typnotnull
             THEN 'NO'::TEXT
         ELSE 'YES'::TEXT END::information_schema.YES_OR_NO AS is_nullable,
    CASE WHEN t.typtype = 'd'::"char"
             THEN CASE WHEN bt.typelem <> 0::OID AND bt.typlen = '-1'::INTEGER
                           THEN 'ARRAY'::TEXT
                       WHEN nbt.nspname = 'pg_catalog'::NAME
                           THEN format_type(t.typbasetype, NULL::INTEGER)
                       ELSE 'USER-DEFINED'::TEXT END
         ELSE CASE WHEN t.typelem <> 0::OID AND t.typlen = '-1'::INTEGER
                       THEN 'ARRAY'::TEXT
                   WHEN nt.nspname = 'pg_catalog'::NAME
                       THEN format_type(a.atttypid, NULL::INTEGER)
                   ELSE 'USER-DEFINED'::TEXT END END::information_schema.CHARACTER_DATA AS data_type,
    information_schema._pg_char_max_length(information_schema._pg_truetypid(a.*, t.*),
                                           information_schema._pg_truetypmod(a.*, t.*))::information_schema.CARDINAL_NUMBER AS character_maximum_length,
    information_schema._pg_char_octet_length(information_schema._pg_truetypid(a.*, t.*),
                                             information_schema._pg_truetypmod(a.*, t.*))::information_schema.CARDINAL_NUMBER AS character_octet_length,
    information_schema._pg_numeric_precision(information_schema._pg_truetypid(a.*, t.*),
                                             information_schema._pg_truetypmod(a.*, t.*))::information_schema.CARDINAL_NUMBER AS numeric_precision,
    information_schema._pg_numeric_precision_radix(information_schema._pg_truetypid(a.*, t.*),
                                                   information_schema._pg_truetypmod(a.*, t.*))::information_schema.CARDINAL_NUMBER AS numeric_precision_radix,
    information_schema._pg_numeric_scale(information_schema._pg_truetypid(a.*, t.*),
                                         information_schema._pg_truetypmod(a.*, t.*))::information_schema.CARDINAL_NUMBER AS numeric_scale,
    information_schema._pg_datetime_precision(information_schema._pg_truetypid(a.*, t.*),
                                              information_schema._pg_truetypmod(a.*, t.*))::information_schema.CARDINAL_NUMBER AS datetime_precision,
    information_schema._pg_interval_type(information_schema._pg_truetypid(a.*, t.*),
                                         information_schema._pg_truetypmod(a.*, t.*))::information_schema.CHARACTER_DATA AS interval_type,
    NULL::INTEGER::information_schema.CARDINAL_NUMBER AS interval_precision,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS character_set_catalog,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS character_set_schema,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS character_set_name,
    CASE WHEN nco.nspname IS NOT NULL
             THEN current_database()
         ELSE NULL::NAME END::information_schema.SQL_IDENTIFIER AS collation_catalog,
    nco.nspname::information_schema.SQL_IDENTIFIER AS collation_schema,
    co.collname::information_schema.SQL_IDENTIFIER AS collation_name,
    CASE WHEN t.typtype = 'd'::"char"
             THEN current_database()
         ELSE NULL::NAME END::information_schema.SQL_IDENTIFIER AS domain_catalog,
    CASE WHEN t.typtype = 'd'::"char" THEN nt.nspname ELSE NULL::NAME END::information_schema.SQL_IDENTIFIER AS domain_schema,
    CASE WHEN t.typtype = 'd'::"char" THEN t.typname ELSE NULL::NAME END::information_schema.SQL_IDENTIFIER AS domain_name,
    current_database()::information_schema.SQL_IDENTIFIER AS udt_catalog,
    COALESCE(nbt.nspname, nt.nspname)::information_schema.SQL_IDENTIFIER AS udt_schema,
    COALESCE(bt.typname, t.typname)::information_schema.SQL_IDENTIFIER AS udt_name,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS scope_catalog,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS scope_schema,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS scope_name,
    NULL::INTEGER::information_schema.CARDINAL_NUMBER AS maximum_cardinality,
    a.attnum::information_schema.SQL_IDENTIFIER AS dtd_identifier,
    'NO'::CHARACTER VARYING::information_schema.YES_OR_NO AS is_self_referencing,
    CASE WHEN a.attidentity = ANY (ARRAY ['a'::"char", 'd'::"char"])
             THEN 'YES'::TEXT
         ELSE 'NO'::TEXT END::information_schema.YES_OR_NO AS is_identity,
    CASE a.attidentity WHEN 'a'::"char"
                           THEN 'ALWAYS'::TEXT
                       WHEN 'd'::"char"
                           THEN 'BY DEFAULT'::TEXT
                       ELSE NULL::TEXT END::information_schema.CHARACTER_DATA AS identity_generation,
    seq.seqstart::information_schema.CHARACTER_DATA AS identity_start,
    seq.seqincrement::information_schema.CHARACTER_DATA AS identity_increment,
    seq.seqmax::information_schema.CHARACTER_DATA AS identity_maximum,
    seq.seqmin::information_schema.CHARACTER_DATA AS identity_minimum,
    CASE WHEN seq.seqcycle THEN 'YES'::TEXT ELSE 'NO'::TEXT END::information_schema.YES_OR_NO AS identity_cycle,
    CASE WHEN a.attgenerated <> ''::"char"
             THEN 'ALWAYS'::TEXT
         ELSE 'NEVER'::TEXT END::information_schema.CHARACTER_DATA AS is_generated,
    CASE WHEN a.attgenerated <> ''::"char"
             THEN pg_get_expr(ad.adbin, ad.adrelid)
         ELSE NULL::TEXT END::information_schema.CHARACTER_DATA AS generation_expression,
    CASE WHEN (c.relkind = ANY (ARRAY ['r'::"char", 'p'::"char"]))
            OR (c.relkind = ANY (ARRAY ['v'::"char", 'f'::"char"]))
                AND pg_column_is_updatable(c.oid::REGCLASS, a.attnum, FALSE)
             THEN 'YES'::TEXT
         ELSE 'NO'::TEXT END::information_schema.YES_OR_NO AS is_updatable
FROM pg_attribute a
         LEFT JOIN pg_attrdef ad ON a.attrelid = ad.adrelid AND a.attnum = ad.adnum
         JOIN (pg_class c JOIN pg_namespace nc ON c.relnamespace = nc.oid) ON a.attrelid = c.oid
         JOIN (pg_type t JOIN pg_namespace nt ON t.typnamespace = nt.oid) ON a.atttypid = t.oid
         LEFT JOIN (pg_type bt JOIN pg_namespace nbt ON bt.typnamespace = nbt.oid)
ON t.typtype = 'd'::"char" AND t.typbasetype = bt.oid
         LEFT JOIN (pg_collation co JOIN pg_namespace nco ON co.collnamespace = nco.oid)
ON a.attcollation = co.oid AND (nco.nspname <> 'pg_catalog'::NAME OR co.collname <> 'default'::NAME)
         LEFT JOIN (pg_depend dep JOIN pg_sequence seq
ON dep.classid = 'pg_class'::REGCLASS::OID AND dep.objid = seq.seqrelid AND dep.deptype = 'i'::"char")
ON dep.refclassid = 'pg_class'::REGCLASS::OID AND dep.refobjid = c.oid AND dep.refobjsubid = a.attnum
WHERE NOT pg_is_other_temp_schema(nc.oid) AND a.attnum > 0 AND NOT a.attisdropped AND
    (c.relkind = ANY (ARRAY ['r'::"char", 'v'::"char", 'f'::"char", 'p'::"char"])) AND
    (pg_has_role(c.relowner, 'USAGE'::TEXT)
            OR has_column_privilege(c.oid, a.attnum, 'SELECT, INSERT, UPDATE, REFERENCES'::TEXT));

ALTER TABLE columns
OWNER TO postgres;

GRANT SELECT ON columns TO PUBLIC;

