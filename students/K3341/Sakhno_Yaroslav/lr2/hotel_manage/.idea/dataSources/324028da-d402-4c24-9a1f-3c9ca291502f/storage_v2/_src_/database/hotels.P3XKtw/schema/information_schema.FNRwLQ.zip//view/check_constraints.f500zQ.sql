CREATE VIEW check_constraints(constraint_catalog, constraint_schema, constraint_name, check_clause) AS
SELECT current_database()::information_schema.SQL_IDENTIFIER AS constraint_catalog,
    rs.nspname::information_schema.SQL_IDENTIFIER AS constraint_schema,
    con.conname::information_schema.SQL_IDENTIFIER AS constraint_name,
    "substring"(pg_get_constraintdef(con.oid), 7)::information_schema.CHARACTER_DATA AS check_clause
FROM pg_constraint con
         LEFT JOIN pg_namespace rs ON rs.oid = con.connamespace
         LEFT JOIN pg_class c ON c.oid = con.conrelid
         LEFT JOIN pg_type t ON t.oid = con.contypid
WHERE pg_has_role(COALESCE(c.relowner, t.typowner), 'USAGE'::TEXT) AND con.contype = 'c'::"char"
UNION
SELECT current_database()::information_schema.SQL_IDENTIFIER AS constraint_catalog,
    n.nspname::information_schema.SQL_IDENTIFIER AS constraint_schema,
    (((((n.oid::TEXT || '_'::TEXT) || r.oid::TEXT) || '_'::TEXT) || a.attnum::TEXT)
            || '_not_null'::TEXT)::information_schema.SQL_IDENTIFIER AS constraint_name,
    (a.attname::TEXT || ' IS NOT NULL'::TEXT)::information_schema.CHARACTER_DATA AS check_clause
FROM pg_namespace n, pg_class r, pg_attribute a
WHERE n.oid = r.relnamespace AND r.oid = a.attrelid AND a.attnum > 0 AND NOT a.attisdropped AND a.attnotnull AND
    (r.relkind = ANY (ARRAY ['r'::"char", 'p'::"char"])) AND pg_has_role(r.relowner, 'USAGE'::TEXT);

ALTER TABLE check_constraints
OWNER TO postgres;

GRANT SELECT ON check_constraints TO PUBLIC;

