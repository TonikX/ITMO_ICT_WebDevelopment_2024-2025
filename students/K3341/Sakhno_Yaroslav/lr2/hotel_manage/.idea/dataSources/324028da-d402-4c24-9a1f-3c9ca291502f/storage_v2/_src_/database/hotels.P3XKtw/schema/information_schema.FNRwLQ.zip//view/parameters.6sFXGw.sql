CREATE VIEW parameters
            (specific_catalog, specific_schema, specific_name, ordinal_position, parameter_mode, is_result, as_locator,
             parameter_name, data_type, character_maximum_length, character_octet_length, character_set_catalog,
             character_set_schema, character_set_name, collation_catalog, collation_schema, collation_name,
             numeric_precision, numeric_precision_radix, numeric_scale, datetime_precision, interval_type,
             interval_precision, udt_catalog, udt_schema, udt_name, scope_catalog, scope_schema, scope_name,
             maximum_cardinality, dtd_identifier, parameter_default)
AS
SELECT current_database()::information_schema.SQL_IDENTIFIER AS specific_catalog,
    ss.n_nspname::information_schema.SQL_IDENTIFIER AS specific_schema,
    nameconcatoid(ss.proname, ss.p_oid)::information_schema.SQL_IDENTIFIER AS specific_name,
    (ss.x).n::information_schema.CARDINAL_NUMBER AS ordinal_position,
    CASE WHEN ss.proargmodes IS NULL
             THEN 'IN'::TEXT
         WHEN ss.proargmodes[(ss.x).n] = 'i'::"char"
             THEN 'IN'::TEXT
         WHEN ss.proargmodes[(ss.x).n] = 'o'::"char"
             THEN 'OUT'::TEXT
         WHEN ss.proargmodes[(ss.x).n] = 'b'::"char"
             THEN 'INOUT'::TEXT
         WHEN ss.proargmodes[(ss.x).n] = 'v'::"char"
             THEN 'IN'::TEXT
         WHEN ss.proargmodes[(ss.x).n] = 't'::"char"
             THEN 'OUT'::TEXT
         ELSE NULL::TEXT END::information_schema.CHARACTER_DATA AS parameter_mode,
    'NO'::CHARACTER VARYING::information_schema.YES_OR_NO AS is_result,
    'NO'::CHARACTER VARYING::information_schema.YES_OR_NO AS as_locator,
    NULLIF(ss.proargnames[(ss.x).n], ''::TEXT)::information_schema.SQL_IDENTIFIER AS parameter_name,
    CASE WHEN t.typelem <> 0::OID AND t.typlen = '-1'::INTEGER
             THEN 'ARRAY'::TEXT
         WHEN nt.nspname = 'pg_catalog'::NAME
             THEN format_type(t.oid, NULL::INTEGER)
         ELSE 'USER-DEFINED'::TEXT END::information_schema.CHARACTER_DATA AS data_type,
    NULL::INTEGER::information_schema.CARDINAL_NUMBER AS character_maximum_length,
    NULL::INTEGER::information_schema.CARDINAL_NUMBER AS character_octet_length,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS character_set_catalog,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS character_set_schema,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS character_set_name,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS collation_catalog,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS collation_schema,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS collation_name,
    NULL::INTEGER::information_schema.CARDINAL_NUMBER AS numeric_precision,
    NULL::INTEGER::information_schema.CARDINAL_NUMBER AS numeric_precision_radix,
    NULL::INTEGER::information_schema.CARDINAL_NUMBER AS numeric_scale,
    NULL::INTEGER::information_schema.CARDINAL_NUMBER AS datetime_precision,
    NULL::CHARACTER VARYING::information_schema.CHARACTER_DATA AS interval_type,
    NULL::INTEGER::information_schema.CARDINAL_NUMBER AS interval_precision,
    current_database()::information_schema.SQL_IDENTIFIER AS udt_catalog,
    nt.nspname::information_schema.SQL_IDENTIFIER AS udt_schema,
    t.typname::information_schema.SQL_IDENTIFIER AS udt_name,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS scope_catalog,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS scope_schema,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS scope_name,
    NULL::INTEGER::information_schema.CARDINAL_NUMBER AS maximum_cardinality,
    (ss.x).n::information_schema.SQL_IDENTIFIER AS dtd_identifier,
    CASE WHEN pg_has_role(ss.proowner, 'USAGE'::TEXT)
             THEN pg_get_function_arg_default(ss.p_oid, (ss.x).n)
         ELSE NULL::TEXT END::information_schema.CHARACTER_DATA AS parameter_default
FROM pg_type t,
    pg_namespace nt,
    (SELECT n.nspname AS n_nspname, p.proname, p.oid AS p_oid, p.proowner, p.proargnames, p.proargmodes,
         information_schema._pg_expandarray(COALESCE(p.proallargtypes, p.proargtypes::OID[])) AS x
     FROM pg_namespace n, pg_proc p
     WHERE n.oid = p.pronamespace AND
         (pg_has_role(p.proowner, 'USAGE'::TEXT) OR has_function_privilege(p.oid, 'EXECUTE'::TEXT))) ss
WHERE t.oid = (ss.x).x AND t.typnamespace = nt.oid;

ALTER TABLE parameters
OWNER TO postgres;

GRANT SELECT ON parameters TO PUBLIC;

