CREATE VIEW udt_privileges (grantor, grantee, udt_catalog, udt_schema, udt_name, privilege_type, is_grantable) AS
SELECT u_grantor.rolname::information_schema.SQL_IDENTIFIER AS grantor,
    grantee.rolname::information_schema.SQL_IDENTIFIER AS grantee,
    current_database()::information_schema.SQL_IDENTIFIER AS udt_catalog,
    n.nspname::information_schema.SQL_IDENTIFIER AS udt_schema,
    t.typname::information_schema.SQL_IDENTIFIER AS udt_name,
    'TYPE USAGE'::CHARACTER VARYING::information_schema.CHARACTER_DATA AS privilege_type,
    CASE WHEN pg_has_role(grantee.oid, t.typowner, 'USAGE'::TEXT) OR t.grantable
             THEN 'YES'::TEXT
         ELSE 'NO'::TEXT END::information_schema.YES_OR_NO AS is_grantable
FROM (SELECT pg_type.oid, pg_type.typname, pg_type.typnamespace, pg_type.typtype, pg_type.typowner,
          (aclexplode(COALESCE(pg_type.typacl, acldefault('T'::"char", pg_type.typowner)))).grantor AS grantor,
          (aclexplode(COALESCE(pg_type.typacl, acldefault('T'::"char", pg_type.typowner)))).grantee AS grantee,
          (aclexplode(COALESCE(pg_type.typacl,
                               acldefault('T'::"char", pg_type.typowner)))).privilege_type AS privilege_type,
          (aclexplode(COALESCE(pg_type.typacl, acldefault('T'::"char", pg_type.typowner)))).is_grantable AS is_grantable
      FROM pg_type) t(oid, typname, typnamespace, typtype, typowner, grantor, grantee, prtype, grantable),
    pg_namespace n,
    pg_authid u_grantor,
    (SELECT pg_authid.oid, pg_authid.rolname
     FROM pg_authid
     UNION ALL
     SELECT 0::OID AS oid, 'PUBLIC'::NAME) grantee(oid, rolname)
WHERE t.typnamespace = n.oid AND t.typtype = 'c'::"char" AND t.grantee = grantee.oid AND t.grantor = u_grantor.oid AND
    t.prtype = 'USAGE'::TEXT AND
    (pg_has_role(u_grantor.oid, 'USAGE'::TEXT) OR pg_has_role(grantee.oid, 'USAGE'::TEXT)
            OR grantee.rolname = 'PUBLIC'::NAME);

ALTER TABLE udt_privileges
OWNER TO postgres;

GRANT SELECT ON udt_privileges TO PUBLIC;

