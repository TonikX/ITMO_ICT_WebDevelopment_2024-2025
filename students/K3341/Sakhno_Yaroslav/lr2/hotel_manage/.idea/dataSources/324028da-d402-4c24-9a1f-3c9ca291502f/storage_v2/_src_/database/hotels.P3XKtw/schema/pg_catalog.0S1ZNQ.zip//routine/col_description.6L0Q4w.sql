CREATE FUNCTION col_description(oid, integer) RETURNS text
    STABLE STRICT PARALLEL SAFE
    LANGUAGE sql AS
$$select description from pg_catalog.pg_description where objoid = $1 and classoid = 'pg_catalog.pg_class'::pg_catalog.regclass and objsubid = $2$$;

COMMENT ON FUNCTION col_description(OID, INTEGER) IS 'get description for table column';

ALTER FUNCTION col_description(OID, INTEGER) OWNER TO postgres;

