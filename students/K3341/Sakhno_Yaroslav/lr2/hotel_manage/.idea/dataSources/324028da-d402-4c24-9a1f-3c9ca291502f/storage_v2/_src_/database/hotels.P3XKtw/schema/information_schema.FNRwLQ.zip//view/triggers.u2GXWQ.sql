CREATE VIEW triggers
            (trigger_catalog, trigger_schema, trigger_name, event_manipulation, event_object_catalog,
             event_object_schema, event_object_table, action_order, action_condition, action_statement,
             action_orientation, action_timing, action_reference_old_table, action_reference_new_table,
             action_reference_old_row, action_reference_new_row, created)
AS
SELECT current_database()::information_schema.SQL_IDENTIFIER AS trigger_catalog,
    n.nspname::information_schema.SQL_IDENTIFIER AS trigger_schema,
    t.tgname::information_schema.SQL_IDENTIFIER AS trigger_name,
    em.text::information_schema.CHARACTER_DATA AS event_manipulation,
    current_database()::information_schema.SQL_IDENTIFIER AS event_object_catalog,
    n.nspname::information_schema.SQL_IDENTIFIER AS event_object_schema,
    c.relname::information_schema.SQL_IDENTIFIER AS event_object_table,
            rank()
            OVER (PARTITION BY (n.nspname::information_schema.SQL_IDENTIFIER), (c.relname::information_schema.SQL_IDENTIFIER), em.num, (t.tgtype::INTEGER & 1), (t.tgtype::INTEGER & 66) ORDER BY t.tgname)::information_schema.CARDINAL_NUMBER AS action_order,
    CASE WHEN pg_has_role(c.relowner, 'USAGE'::TEXT)
             THEN (regexp_match(pg_get_triggerdef(t.oid), '.{35,} WHEN \((.+)\) EXECUTE FUNCTION'::TEXT))[1]
         ELSE NULL::TEXT END::information_schema.CHARACTER_DATA AS action_condition,
    "substring"(pg_get_triggerdef(t.oid),
                "position"("substring"(pg_get_triggerdef(t.oid), 48), 'EXECUTE FUNCTION'::TEXT)
                        + 47)::information_schema.CHARACTER_DATA AS action_statement,
    CASE t.tgtype::INTEGER & 1 WHEN 1
                                   THEN 'ROW'::TEXT
                               ELSE 'STATEMENT'::TEXT END::information_schema.CHARACTER_DATA AS action_orientation,
    CASE t.tgtype::INTEGER & 66 WHEN 2
                                    THEN 'BEFORE'::TEXT
                                WHEN 64
                                    THEN 'INSTEAD OF'::TEXT
                                ELSE 'AFTER'::TEXT END::information_schema.CHARACTER_DATA AS action_timing,
    t.tgoldtable::information_schema.SQL_IDENTIFIER AS action_reference_old_table,
    t.tgnewtable::information_schema.SQL_IDENTIFIER AS action_reference_new_table,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS action_reference_old_row,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS action_reference_new_row,
    NULL::TIMESTAMP WITH TIME ZONE::information_schema.TIME_STAMP AS created
FROM pg_namespace n,
    pg_class c,
    pg_trigger t,
    (VALUES (4, 'INSERT'::TEXT), (8, 'DELETE'::TEXT), (16, 'UPDATE'::TEXT)) em(num, text)
WHERE n.oid = c.relnamespace AND c.oid = t.tgrelid AND (t.tgtype::INTEGER & em.num) <> 0 AND NOT t.tgisinternal AND
    NOT pg_is_other_temp_schema(n.oid) AND
    (pg_has_role(c.relowner, 'USAGE'::TEXT)
            OR has_table_privilege(c.oid, 'INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::TEXT)
            OR has_any_column_privilege(c.oid, 'INSERT, UPDATE, REFERENCES'::TEXT));

ALTER TABLE triggers
OWNER TO postgres;

GRANT SELECT ON triggers TO PUBLIC;

