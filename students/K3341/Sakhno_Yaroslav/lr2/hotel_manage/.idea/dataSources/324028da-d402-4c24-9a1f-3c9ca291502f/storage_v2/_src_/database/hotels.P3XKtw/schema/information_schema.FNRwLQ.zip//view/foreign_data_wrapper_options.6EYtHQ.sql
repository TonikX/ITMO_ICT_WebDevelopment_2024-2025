CREATE VIEW foreign_data_wrapper_options
            (foreign_data_wrapper_catalog, foreign_data_wrapper_name, option_name, option_value) AS
SELECT w.foreign_data_wrapper_catalog, w.foreign_data_wrapper_name,
    (pg_options_to_table(w.fdwoptions)).option_name::information_schema.SQL_IDENTIFIER AS option_name,
    (pg_options_to_table(w.fdwoptions)).option_value::information_schema.CHARACTER_DATA AS option_value
FROM information_schema._pg_foreign_data_wrappers w;

ALTER TABLE foreign_data_wrapper_options
OWNER TO postgres;

GRANT SELECT ON foreign_data_wrapper_options TO PUBLIC;

