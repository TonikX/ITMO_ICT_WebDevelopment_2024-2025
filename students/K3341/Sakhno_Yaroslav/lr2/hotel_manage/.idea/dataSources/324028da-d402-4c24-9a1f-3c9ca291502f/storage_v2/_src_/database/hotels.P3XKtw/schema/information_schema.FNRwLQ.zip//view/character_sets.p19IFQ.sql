CREATE VIEW character_sets
            (character_set_catalog, character_set_schema, character_set_name, character_repertoire, form_of_use,
             default_collate_catalog, default_collate_schema, default_collate_name)
AS
SELECT NULL::NAME::information_schema.SQL_IDENTIFIER AS character_set_catalog,
    NULL::NAME::information_schema.SQL_IDENTIFIER AS character_set_schema,
    getdatabaseencoding()::information_schema.SQL_IDENTIFIER AS character_set_name,
    CASE WHEN getdatabaseencoding() = 'UTF8'::NAME
             THEN 'UCS'::NAME
         ELSE getdatabaseencoding() END::information_schema.SQL_IDENTIFIER AS character_repertoire,
    getdatabaseencoding()::information_schema.SQL_IDENTIFIER AS form_of_use,
    current_database()::information_schema.SQL_IDENTIFIER AS default_collate_catalog,
    nc.nspname::information_schema.SQL_IDENTIFIER AS default_collate_schema,
    c.collname::information_schema.SQL_IDENTIFIER AS default_collate_name
FROM pg_database d
         LEFT JOIN (pg_collation c JOIN pg_namespace nc ON c.collnamespace = nc.oid)
ON d.datcollate = c.collcollate AND d.datctype = c.collctype
WHERE d.datname = current_database()
ORDER BY (char_length(c.collname::TEXT)) DESC, c.collname
LIMIT 1;

ALTER TABLE character_sets
OWNER TO postgres;

GRANT SELECT ON character_sets TO PUBLIC;

