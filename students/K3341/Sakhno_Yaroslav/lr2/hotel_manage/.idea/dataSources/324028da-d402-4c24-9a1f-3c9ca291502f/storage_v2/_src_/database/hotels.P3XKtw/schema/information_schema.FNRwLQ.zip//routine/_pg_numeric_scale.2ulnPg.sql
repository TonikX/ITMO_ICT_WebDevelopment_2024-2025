CREATE FUNCTION _pg_numeric_scale(typid oid, typmod integer) RETURNS integer
    IMMUTABLE STRICT PARALLEL SAFE
    LANGUAGE sql AS
$$SELECT
  CASE WHEN $1 IN (21, 23, 20) THEN 0
       WHEN $1 IN (1700) THEN
            CASE WHEN $2 = -1
                 THEN null
                 ELSE ($2 - 4) & 65535
                 END
       ELSE null
  END$$;

ALTER FUNCTION _pg_numeric_scale(OID, INTEGER) OWNER TO postgres;

