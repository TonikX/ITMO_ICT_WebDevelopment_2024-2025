CREATE VIEW pg_matviews (schemaname, matviewname, matviewowner, tablespace, hasindexes, ispopulated, definition) AS
SELECT n.nspname AS schemaname, c.relname AS matviewname, pg_get_userbyid(c.relowner) AS matviewowner,
    t.spcname AS tablespace, c.relhasindex AS hasindexes, c.relispopulated AS ispopulated,
    pg_get_viewdef(c.oid) AS definition
FROM pg_class c
         LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
         LEFT JOIN pg_tablespace t ON t.oid = c.reltablespace
WHERE c.relkind = 'm'::"char";

ALTER TABLE pg_matviews
OWNER TO postgres;

GRANT SELECT ON pg_matviews TO PUBLIC;

