CREATE VIEW pg_statio_user_indexes
            (relid, indexrelid, schemaname, relname, indexrelname, idx_blks_read, idx_blks_hit) AS
SELECT pg_statio_all_indexes.relid, pg_statio_all_indexes.indexrelid, pg_statio_all_indexes.schemaname,
    pg_statio_all_indexes.relname, pg_statio_all_indexes.indexrelname, pg_statio_all_indexes.idx_blks_read,
    pg_statio_all_indexes.idx_blks_hit
FROM pg_statio_all_indexes
WHERE (pg_statio_all_indexes.schemaname <> ALL (ARRAY ['pg_catalog'::NAME, 'information_schema'::NAME])) AND
    pg_statio_all_indexes.schemaname !~ '^pg_toast'::TEXT;

ALTER TABLE pg_statio_user_indexes
OWNER TO postgres;

GRANT SELECT ON pg_statio_user_indexes TO PUBLIC;

