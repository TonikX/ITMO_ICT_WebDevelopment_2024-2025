CREATE VIEW pg_user (usename, usesysid, usecreatedb, usesuper, userepl, usebypassrls, passwd, valuntil, useconfig) AS
SELECT pg_shadow.usename, pg_shadow.usesysid, pg_shadow.usecreatedb, pg_shadow.usesuper, pg_shadow.userepl,
    pg_shadow.usebypassrls, '********'::TEXT AS passwd, pg_shadow.valuntil, pg_shadow.useconfig
FROM pg_shadow;

ALTER TABLE pg_user
OWNER TO postgres;

GRANT SELECT ON pg_user TO PUBLIC;

