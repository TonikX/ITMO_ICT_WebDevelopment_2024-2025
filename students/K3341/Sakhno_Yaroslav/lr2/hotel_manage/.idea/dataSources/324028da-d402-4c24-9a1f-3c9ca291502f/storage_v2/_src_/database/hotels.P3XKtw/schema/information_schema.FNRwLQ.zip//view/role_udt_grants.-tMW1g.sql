CREATE VIEW role_udt_grants (grantor, grantee, udt_catalog, udt_schema, udt_name, privilege_type, is_grantable) AS
SELECT udt_privileges.grantor, udt_privileges.grantee, udt_privileges.udt_catalog, udt_privileges.udt_schema,
    udt_privileges.udt_name, udt_privileges.privilege_type, udt_privileges.is_grantable
FROM information_schema.udt_privileges
WHERE (udt_privileges.grantor::NAME IN (SELECT enabled_roles.role_name FROM information_schema.enabled_roles)) OR
    (udt_privileges.grantee::NAME IN (SELECT enabled_roles.role_name FROM information_schema.enabled_roles));

ALTER TABLE role_udt_grants
OWNER TO postgres;

GRANT SELECT ON role_udt_grants TO PUBLIC;

