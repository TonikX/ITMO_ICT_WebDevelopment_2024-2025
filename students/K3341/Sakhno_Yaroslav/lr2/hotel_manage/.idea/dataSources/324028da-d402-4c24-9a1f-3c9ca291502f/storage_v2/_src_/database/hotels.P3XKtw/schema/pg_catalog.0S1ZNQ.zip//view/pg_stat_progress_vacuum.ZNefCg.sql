CREATE VIEW pg_stat_progress_vacuum
            (pid, datid, datname, relid, phase, heap_blks_total, heap_blks_scanned, heap_blks_vacuumed,
             index_vacuum_count, max_dead_tuples, num_dead_tuples)
AS
SELECT s.pid, s.datid, d.datname, s.relid,
    CASE s.param1 WHEN 0
                      THEN 'initializing'::TEXT
                  WHEN 1
                      THEN 'scanning heap'::TEXT
                  WHEN 2
                      THEN 'vacuuming indexes'::TEXT
                  WHEN 3
                      THEN 'vacuuming heap'::TEXT
                  WHEN 4
                      THEN 'cleaning up indexes'::TEXT
                  WHEN 5
                      THEN 'truncating heap'::TEXT
                  WHEN 6
                      THEN 'performing final cleanup'::TEXT
                  ELSE NULL::TEXT END AS phase, s.param2 AS heap_blks_total, s.param3 AS heap_blks_scanned,
    s.param4 AS heap_blks_vacuumed, s.param5 AS index_vacuum_count, s.param6 AS max_dead_tuples,
    s.param7 AS num_dead_tuples
FROM pg_stat_get_progress_info('VACUUM'::TEXT) s(pid, datid, relid, param1, param2, param3, param4, param5, param6,
                                                 param7, param8, param9, param10, param11, param12, param13, param14,
                                                 param15, param16, param17, param18, param19, param20)
         LEFT JOIN pg_database d ON s.datid = d.oid;

ALTER TABLE pg_stat_progress_vacuum
OWNER TO postgres;

GRANT SELECT ON pg_stat_progress_vacuum TO PUBLIC;

