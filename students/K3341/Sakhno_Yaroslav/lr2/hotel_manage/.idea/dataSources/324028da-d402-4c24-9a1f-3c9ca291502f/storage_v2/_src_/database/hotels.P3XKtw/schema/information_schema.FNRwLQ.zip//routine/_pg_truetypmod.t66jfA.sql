CREATE FUNCTION _pg_truetypmod(pg_attribute, pg_type) RETURNS integer
    IMMUTABLE STRICT PARALLEL SAFE
    LANGUAGE sql AS
$$SELECT CASE WHEN $2.typtype = 'd' THEN $2.typtypmod ELSE $1.atttypmod END$$;

ALTER FUNCTION _pg_truetypmod(PG_ATTRIBUTE, PG_TYPE) OWNER TO postgres;

