CREATE VIEW pg_seclabels (objoid, classoid, objsubid, objtype, objnamespace, objname, provider, label) AS
SELECT l.objoid, l.classoid, l.objsubid,
    CASE WHEN rel.relkind = ANY (ARRAY ['r'::"char", 'p'::"char"])
             THEN 'table'::TEXT
         WHEN rel.relkind = 'v'::"char"
             THEN 'view'::TEXT
         WHEN rel.relkind = 'm'::"char"
             THEN 'materialized view'::TEXT
         WHEN rel.relkind = 'S'::"char"
             THEN 'sequence'::TEXT
         WHEN rel.relkind = 'f'::"char"
             THEN 'foreign table'::TEXT
         ELSE NULL::TEXT END AS objtype, rel.relnamespace AS objnamespace,
    CASE WHEN pg_table_is_visible(rel.oid)
             THEN quote_ident(rel.relname::TEXT)
         ELSE (quote_ident(nsp.nspname::TEXT) || '.'::TEXT) || quote_ident(rel.relname::TEXT) END AS objname,
    l.provider, l.label
FROM pg_seclabel l
         JOIN pg_class rel ON l.classoid = rel.tableoid AND l.objoid = rel.oid
         JOIN pg_namespace nsp ON rel.relnamespace = nsp.oid
WHERE l.objsubid = 0
UNION ALL
SELECT l.objoid, l.classoid, l.objsubid, 'column'::TEXT AS objtype, rel.relnamespace AS objnamespace,
    (CASE WHEN pg_table_is_visible(rel.oid)
              THEN quote_ident(rel.relname::TEXT)
          ELSE (quote_ident(nsp.nspname::TEXT) || '.'::TEXT) || quote_ident(rel.relname::TEXT) END || '.'::TEXT)
            || att.attname::TEXT AS objname, l.provider, l.label
FROM pg_seclabel l
         JOIN pg_class rel ON l.classoid = rel.tableoid AND l.objoid = rel.oid
         JOIN pg_attribute att ON rel.oid = att.attrelid AND l.objsubid = att.attnum
         JOIN pg_namespace nsp ON rel.relnamespace = nsp.oid
WHERE l.objsubid <> 0
UNION ALL
SELECT l.objoid, l.classoid, l.objsubid,
    CASE pro.prokind WHEN 'a'::"char"
                         THEN 'aggregate'::TEXT
                     WHEN 'f'::"char"
                         THEN 'function'::TEXT
                     WHEN 'p'::"char"
                         THEN 'procedure'::TEXT
                     WHEN 'w'::"char"
                         THEN 'window'::TEXT
                     ELSE NULL::TEXT END AS objtype, pro.pronamespace AS objnamespace,
    ((CASE WHEN pg_function_is_visible(pro.oid)
               THEN quote_ident(pro.proname::TEXT)
           ELSE (quote_ident(nsp.nspname::TEXT) || '.'::TEXT) || quote_ident(pro.proname::TEXT) END || '('::TEXT)
            || pg_get_function_arguments(pro.oid)) || ')'::TEXT AS objname, l.provider, l.label
FROM pg_seclabel l
         JOIN pg_proc pro ON l.classoid = pro.tableoid AND l.objoid = pro.oid
         JOIN pg_namespace nsp ON pro.pronamespace = nsp.oid
WHERE l.objsubid = 0
UNION ALL
SELECT l.objoid, l.classoid, l.objsubid, CASE WHEN typ.typtype = 'd'::"char"
                                                  THEN 'domain'::TEXT
                                              ELSE 'type'::TEXT END AS objtype, typ.typnamespace AS objnamespace,
    CASE WHEN pg_type_is_visible(typ.oid)
             THEN quote_ident(typ.typname::TEXT)
         ELSE (quote_ident(nsp.nspname::TEXT) || '.'::TEXT) || quote_ident(typ.typname::TEXT) END AS objname,
    l.provider, l.label
FROM pg_seclabel l
         JOIN pg_type typ ON l.classoid = typ.tableoid AND l.objoid = typ.oid
         JOIN pg_namespace nsp ON typ.typnamespace = nsp.oid
WHERE l.objsubid = 0
UNION ALL
SELECT l.objoid, l.classoid, l.objsubid, 'large object'::TEXT AS objtype, NULL::OID AS objnamespace,
    l.objoid::TEXT AS objname, l.provider, l.label
FROM pg_seclabel l
         JOIN pg_largeobject_metadata lom ON l.objoid = lom.oid
WHERE l.classoid = 'pg_largeobject'::REGCLASS::OID AND l.objsubid = 0
UNION ALL
SELECT l.objoid, l.classoid, l.objsubid, 'language'::TEXT AS objtype, NULL::OID AS objnamespace,
    quote_ident(lan.lanname::TEXT) AS objname, l.provider, l.label
FROM pg_seclabel l
         JOIN pg_language lan ON l.classoid = lan.tableoid AND l.objoid = lan.oid
WHERE l.objsubid = 0
UNION ALL
SELECT l.objoid, l.classoid, l.objsubid, 'schema'::TEXT AS objtype, nsp.oid AS objnamespace,
    quote_ident(nsp.nspname::TEXT) AS objname, l.provider, l.label
FROM pg_seclabel l
         JOIN pg_namespace nsp ON l.classoid = nsp.tableoid AND l.objoid = nsp.oid
WHERE l.objsubid = 0
UNION ALL
SELECT l.objoid, l.classoid, l.objsubid, 'event trigger'::TEXT AS objtype, NULL::OID AS objnamespace,
    quote_ident(evt.evtname::TEXT) AS objname, l.provider, l.label
FROM pg_seclabel l
         JOIN pg_event_trigger evt ON l.classoid = evt.tableoid AND l.objoid = evt.oid
WHERE l.objsubid = 0
UNION ALL
SELECT l.objoid, l.classoid, l.objsubid, 'publication'::TEXT AS objtype, NULL::OID AS objnamespace,
    quote_ident(p.pubname::TEXT) AS objname, l.provider, l.label
FROM pg_seclabel l
         JOIN pg_publication p ON l.classoid = p.tableoid AND l.objoid = p.oid
WHERE l.objsubid = 0
UNION ALL
SELECT l.objoid, l.classoid, 0 AS objsubid, 'subscription'::TEXT AS objtype, NULL::OID AS objnamespace,
    quote_ident(s.subname::TEXT) AS objname, l.provider, l.label
FROM pg_shseclabel l
         JOIN pg_subscription s ON l.classoid = s.tableoid AND l.objoid = s.oid
UNION ALL
SELECT l.objoid, l.classoid, 0 AS objsubid, 'database'::TEXT AS objtype, NULL::OID AS objnamespace,
    quote_ident(dat.datname::TEXT) AS objname, l.provider, l.label
FROM pg_shseclabel l
         JOIN pg_database dat ON l.classoid = dat.tableoid AND l.objoid = dat.oid
UNION ALL
SELECT l.objoid, l.classoid, 0 AS objsubid, 'tablespace'::TEXT AS objtype, NULL::OID AS objnamespace,
    quote_ident(spc.spcname::TEXT) AS objname, l.provider, l.label
FROM pg_shseclabel l
         JOIN pg_tablespace spc ON l.classoid = spc.tableoid AND l.objoid = spc.oid
UNION ALL
SELECT l.objoid, l.classoid, 0 AS objsubid, 'role'::TEXT AS objtype, NULL::OID AS objnamespace,
    quote_ident(rol.rolname::TEXT) AS objname, l.provider, l.label
FROM pg_shseclabel l
         JOIN pg_authid rol ON l.classoid = rol.tableoid AND l.objoid = rol.oid;

ALTER TABLE pg_seclabels
OWNER TO postgres;

GRANT SELECT ON pg_seclabels TO PUBLIC;

