CREATE VIEW role_routine_grants
            (grantor, grantee, specific_catalog, specific_schema, specific_name, routine_catalog, routine_schema,
             routine_name, privilege_type, is_grantable)
AS
SELECT routine_privileges.grantor, routine_privileges.grantee, routine_privileges.specific_catalog,
    routine_privileges.specific_schema, routine_privileges.specific_name, routine_privileges.routine_catalog,
    routine_privileges.routine_schema, routine_privileges.routine_name, routine_privileges.privilege_type,
    routine_privileges.is_grantable
FROM information_schema.routine_privileges
WHERE (routine_privileges.grantor::NAME IN (SELECT enabled_roles.role_name FROM information_schema.enabled_roles)) OR
    (routine_privileges.grantee::NAME IN (SELECT enabled_roles.role_name FROM information_schema.enabled_roles));

ALTER TABLE role_routine_grants
OWNER TO postgres;

GRANT SELECT ON role_routine_grants TO PUBLIC;

