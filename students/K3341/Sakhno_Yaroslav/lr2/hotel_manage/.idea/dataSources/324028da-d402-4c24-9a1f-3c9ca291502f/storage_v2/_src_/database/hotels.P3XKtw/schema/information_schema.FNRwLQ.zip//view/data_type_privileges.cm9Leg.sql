CREATE VIEW data_type_privileges (object_catalog, object_schema, object_name, object_type, dtd_identifier) AS
SELECT current_database()::information_schema.SQL_IDENTIFIER AS object_catalog, x.objschema AS object_schema,
    x.objname AS object_name, x.objtype::information_schema.CHARACTER_DATA AS object_type, x.objdtdid AS dtd_identifier
FROM (SELECT attributes.udt_schema, attributes.udt_name, 'USER-DEFINED TYPE'::TEXT AS text, attributes.dtd_identifier
      FROM information_schema.attributes
      UNION ALL
      SELECT columns.table_schema, columns.table_name, 'TABLE'::TEXT AS text, columns.dtd_identifier
      FROM information_schema.columns
      UNION ALL
      SELECT domains.domain_schema, domains.domain_name, 'DOMAIN'::TEXT AS text, domains.dtd_identifier
      FROM information_schema.domains
      UNION ALL
      SELECT parameters.specific_schema, parameters.specific_name, 'ROUTINE'::TEXT AS text, parameters.dtd_identifier
      FROM information_schema.parameters
      UNION ALL
      SELECT routines.specific_schema, routines.specific_name, 'ROUTINE'::TEXT AS text, routines.dtd_identifier
      FROM information_schema.routines) x(objschema, objname, objtype, objdtdid);

ALTER TABLE data_type_privileges
OWNER TO postgres;

GRANT SELECT ON data_type_privileges TO PUBLIC;

