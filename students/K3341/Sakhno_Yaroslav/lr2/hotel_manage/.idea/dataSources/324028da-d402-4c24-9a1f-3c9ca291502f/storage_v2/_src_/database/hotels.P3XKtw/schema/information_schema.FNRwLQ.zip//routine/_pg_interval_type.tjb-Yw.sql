CREATE FUNCTION _pg_interval_type(typid oid, mod integer) RETURNS text
    IMMUTABLE STRICT PARALLEL SAFE
    LANGUAGE sql AS
$$SELECT
  CASE WHEN $1 IN (1186) /* interval */
           THEN pg_catalog.upper(substring(pg_catalog.format_type($1, $2) from 'interval[()0-9]* #"%#"' for '#'))
       ELSE null
  END$$;

ALTER FUNCTION _pg_interval_type(OID, INTEGER) OWNER TO postgres;

