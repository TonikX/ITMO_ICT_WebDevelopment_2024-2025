CREATE FUNCTION pg_sleep_until(timestamp with time zone) RETURNS void
    STRICT PARALLEL SAFE COST 1
    LANGUAGE sql AS
$$select pg_catalog.pg_sleep(extract(epoch from $1) operator(pg_catalog.-) extract(epoch from pg_catalog.clock_timestamp()))$$;

COMMENT ON FUNCTION pg_sleep_until(TIMESTAMP WITH TIME ZONE) IS 'sleep until the specified time';

ALTER FUNCTION pg_sleep_until(TIMESTAMP WITH TIME ZONE) OWNER TO postgres;

