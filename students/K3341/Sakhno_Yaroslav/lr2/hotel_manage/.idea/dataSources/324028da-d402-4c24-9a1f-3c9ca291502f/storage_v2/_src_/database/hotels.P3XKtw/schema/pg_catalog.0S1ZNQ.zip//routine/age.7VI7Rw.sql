CREATE FUNCTION age(timestamp with time zone) RETURNS interval
    STABLE STRICT PARALLEL SAFE COST 1
    LANGUAGE sql AS
$$select pg_catalog.age(cast(current_date as timestamp with time zone), $1)$$;

COMMENT ON FUNCTION age(TIMESTAMP WITH TIME ZONE) IS 'date difference from today preserving months and years';

ALTER FUNCTION age(TIMESTAMP WITH TIME ZONE) OWNER TO postgres;

