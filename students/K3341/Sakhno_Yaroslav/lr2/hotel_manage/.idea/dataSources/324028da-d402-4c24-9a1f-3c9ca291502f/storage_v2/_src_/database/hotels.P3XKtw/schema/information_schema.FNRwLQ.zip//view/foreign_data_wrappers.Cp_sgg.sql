CREATE VIEW foreign_data_wrappers
            (foreign_data_wrapper_catalog, foreign_data_wrapper_name, authorization_identifier, library_name,
             foreign_data_wrapper_language)
AS
SELECT w.foreign_data_wrapper_catalog, w.foreign_data_wrapper_name, w.authorization_identifier,
    NULL::CHARACTER VARYING::information_schema.CHARACTER_DATA AS library_name, w.foreign_data_wrapper_language
FROM information_schema._pg_foreign_data_wrappers w;

ALTER TABLE foreign_data_wrappers
OWNER TO postgres;

GRANT SELECT ON foreign_data_wrappers TO PUBLIC;

