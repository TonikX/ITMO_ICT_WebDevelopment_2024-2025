CREATE FUNCTION obj_description(oid, name) RETURNS text
    STABLE STRICT PARALLEL SAFE
    LANGUAGE sql AS
$$select description from pg_catalog.pg_description where objoid = $1 and classoid = (select oid from pg_catalog.pg_class where relname = $2 and relnamespace = 11) and objsubid = 0$$;

COMMENT ON FUNCTION obj_description(OID, NAME) IS 'get description for object id and catalog name';

ALTER FUNCTION obj_description(OID, NAME) OWNER TO postgres;

