CREATE VIEW pg_statio_user_tables
            (relid, schemaname, relname, heap_blks_read, heap_blks_hit, idx_blks_read, idx_blks_hit, toast_blks_read,
             toast_blks_hit, tidx_blks_read, tidx_blks_hit)
AS
SELECT pg_statio_all_tables.relid, pg_statio_all_tables.schemaname, pg_statio_all_tables.relname,
    pg_statio_all_tables.heap_blks_read, pg_statio_all_tables.heap_blks_hit, pg_statio_all_tables.idx_blks_read,
    pg_statio_all_tables.idx_blks_hit, pg_statio_all_tables.toast_blks_read, pg_statio_all_tables.toast_blks_hit,
    pg_statio_all_tables.tidx_blks_read, pg_statio_all_tables.tidx_blks_hit
FROM pg_statio_all_tables
WHERE (pg_statio_all_tables.schemaname <> ALL (ARRAY ['pg_catalog'::NAME, 'information_schema'::NAME])) AND
    pg_statio_all_tables.schemaname !~ '^pg_toast'::TEXT;

ALTER TABLE pg_statio_user_tables
OWNER TO postgres;

GRANT SELECT ON pg_statio_user_tables TO PUBLIC;

