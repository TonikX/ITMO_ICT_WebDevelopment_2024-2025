CREATE VIEW pg_stat_progress_cluster
            (pid, datid, datname, relid, command, phase, cluster_index_relid, heap_tuples_scanned, heap_tuples_written,
             heap_blks_total, heap_blks_scanned, index_rebuild_count)
AS
SELECT s.pid, s.datid, d.datname, s.relid, CASE s.param1 WHEN 1
                                                             THEN 'CLUSTER'::TEXT
                                                         WHEN 2
                                                             THEN 'VACUUM FULL'::TEXT
                                                         ELSE NULL::TEXT END AS command,
    CASE s.param2 WHEN 0
                      THEN 'initializing'::TEXT
                  WHEN 1
                      THEN 'seq scanning heap'::TEXT
                  WHEN 2
                      THEN 'index scanning heap'::TEXT
                  WHEN 3
                      THEN 'sorting tuples'::TEXT
                  WHEN 4
                      THEN 'writing new heap'::TEXT
                  WHEN 5
                      THEN 'swapping relation files'::TEXT
                  WHEN 6
                      THEN 'rebuilding index'::TEXT
                  WHEN 7
                      THEN 'performing final cleanup'::TEXT
                  ELSE NULL::TEXT END AS phase, s.param3::OID AS cluster_index_relid, s.param4 AS heap_tuples_scanned,
    s.param5 AS heap_tuples_written, s.param6 AS heap_blks_total, s.param7 AS heap_blks_scanned,
    s.param8 AS index_rebuild_count
FROM pg_stat_get_progress_info('CLUSTER'::TEXT) s(pid, datid, relid, param1, param2, param3, param4, param5, param6,
                                                  param7, param8, param9, param10, param11, param12, param13, param14,
                                                  param15, param16, param17, param18, param19, param20)
         LEFT JOIN pg_database d ON s.datid = d.oid;

ALTER TABLE pg_stat_progress_cluster
OWNER TO postgres;

GRANT SELECT ON pg_stat_progress_cluster TO PUBLIC;

