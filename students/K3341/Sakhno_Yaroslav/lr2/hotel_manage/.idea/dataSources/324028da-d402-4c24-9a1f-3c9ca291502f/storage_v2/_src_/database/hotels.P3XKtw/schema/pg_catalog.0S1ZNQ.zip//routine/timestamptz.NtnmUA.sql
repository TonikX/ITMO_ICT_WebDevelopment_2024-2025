CREATE FUNCTION timestamptz(date, time without time zone) RETURNS timestamp with time zone
    STABLE STRICT PARALLEL SAFE COST 1
    LANGUAGE sql AS
$$select cast(($1 + $2) as timestamp with time zone)$$;

COMMENT ON FUNCTION timestamptz(DATE, TIME) IS 'convert date and time to timestamp with time zone';

ALTER FUNCTION timestamptz(DATE, TIME) OWNER TO postgres;

