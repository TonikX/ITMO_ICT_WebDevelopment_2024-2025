CREATE VIEW pg_available_extensions(name, default_version, installed_version, comment) AS
SELECT e.name, e.default_version, x.extversion AS installed_version, e.comment
FROM pg_available_extensions() e(name, default_version, comment)
         LEFT JOIN pg_extension x ON e.name = x.extname;

ALTER TABLE pg_available_extensions
OWNER TO postgres;

GRANT SELECT ON pg_available_extensions TO PUBLIC;

