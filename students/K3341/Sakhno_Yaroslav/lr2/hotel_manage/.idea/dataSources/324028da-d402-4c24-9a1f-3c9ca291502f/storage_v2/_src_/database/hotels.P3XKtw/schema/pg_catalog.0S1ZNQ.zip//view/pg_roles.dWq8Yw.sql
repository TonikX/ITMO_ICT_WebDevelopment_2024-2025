CREATE VIEW pg_roles
            (rolname, rolsuper, rolinherit, rolcreaterole, rolcreatedb, rolcanlogin, rolreplication, rolconnlimit,
             rolpassword, rolvaliduntil, rolbypassrls, rolconfig, oid)
AS
SELECT pg_authid.rolname, pg_authid.rolsuper, pg_authid.rolinherit, pg_authid.rolcreaterole, pg_authid.rolcreatedb,
    pg_authid.rolcanlogin, pg_authid.rolreplication, pg_authid.rolconnlimit, '********'::TEXT AS rolpassword,
    pg_authid.rolvaliduntil, pg_authid.rolbypassrls, s.setconfig AS rolconfig, pg_authid.oid
FROM pg_authid
         LEFT JOIN pg_db_role_setting s ON pg_authid.oid = s.setrole AND s.setdatabase = 0::OID;

ALTER TABLE pg_roles
OWNER TO postgres;

GRANT SELECT ON pg_roles TO PUBLIC;

