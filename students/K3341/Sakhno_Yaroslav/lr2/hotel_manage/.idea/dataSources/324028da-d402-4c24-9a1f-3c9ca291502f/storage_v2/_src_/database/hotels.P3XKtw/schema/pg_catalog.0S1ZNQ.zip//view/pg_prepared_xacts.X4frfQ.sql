CREATE VIEW pg_prepared_xacts(transaction, gid, prepared, owner, database) AS
SELECT p.transaction, p.gid, p.prepared, u.rolname AS owner, d.datname AS database
FROM pg_prepared_xact() p(transaction, gid, prepared, ownerid, dbid)
         LEFT JOIN pg_authid u ON p.ownerid = u.oid
         LEFT JOIN pg_database d ON p.dbid = d.oid;

ALTER TABLE pg_prepared_xacts
OWNER TO postgres;

GRANT SELECT ON pg_prepared_xacts TO PUBLIC;

