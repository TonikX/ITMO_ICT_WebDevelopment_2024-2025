CREATE VIEW role_column_grants
            (grantor, grantee, table_catalog, table_schema, table_name, column_name, privilege_type, is_grantable) AS
SELECT column_privileges.grantor, column_privileges.grantee, column_privileges.table_catalog,
    column_privileges.table_schema, column_privileges.table_name, column_privileges.column_name,
    column_privileges.privilege_type, column_privileges.is_grantable
FROM information_schema.column_privileges
WHERE (column_privileges.grantor::NAME IN (SELECT enabled_roles.role_name FROM information_schema.enabled_roles)) OR
    (column_privileges.grantee::NAME IN (SELECT enabled_roles.role_name FROM information_schema.enabled_roles));

ALTER TABLE role_column_grants
OWNER TO postgres;

GRANT SELECT ON role_column_grants TO PUBLIC;

