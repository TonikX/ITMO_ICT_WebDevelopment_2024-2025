CREATE FUNCTION lpad(text, integer) RETURNS text
    IMMUTABLE STRICT PARALLEL SAFE COST 1
    LANGUAGE sql AS
$$select pg_catalog.lpad($1, $2, ' ')$$;

COMMENT ON FUNCTION lpad(TEXT, INTEGER) IS 'left-pad string to length';

ALTER FUNCTION lpad(TEXT, INTEGER) OWNER TO postgres;

